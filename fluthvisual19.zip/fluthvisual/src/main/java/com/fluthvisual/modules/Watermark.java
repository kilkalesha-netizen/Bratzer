package com.fluthvisual.modules;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

public class Watermark {
    public static boolean enabled = true;

    public static void register() {
        HudElementRegistry.attachElementBefore(
            VanillaHudElements.CHAT,
            Identifier.fromNamespaceAndPath("fluthvisual", "watermark"),
            (context, tickCounter) -> render(context)
        );
    }

    private static void render(DrawContext context) {
        if (!enabled) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;

        String text = "Fluth Visual";
        int textWidth = mc.textRenderer.getWidth(text);
        int padding = 4;
        int x = (mc.getWindow().getScaledWidth() / 2) - (textWidth / 2) - padding;
        int y = 4;

        context.fill(x, y, x + textWidth + padding * 2, y + 14, 0xCC1A1A2E);
        context.drawBorder(x, y, textWidth + padding * 2, 14, 0xFF8B5CF6);
        context.drawTextWithShadow(mc.textRenderer, text, x + padding, y + 3, 0xFF8B5CF6);
    }
}